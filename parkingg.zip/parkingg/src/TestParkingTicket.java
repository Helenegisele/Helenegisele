public class TestParkingTicket {
    public void runTests() {
        // Create an officer
        PoliceOfficer officer = new PoliceOfficer("Helene ", "07884015");

        // Test 1: Car within the parking time
        ParkedCar car1 = new ParkedCar("Benz", "Carmen", "Red", "erytri8383", 34);
        ParkingMeter meter1 = new ParkingMeter(60);
        ParkingTicket ticket1 = officer.issueTicket(car1, meter1);
        System.out.println("Test 1: " + (ticket1 != null ? ticket1.generateTicket() : "Allowed"));

        // Test 2: Car over the parking time
        ParkedCar car2 = new ParkedCar("vigo", "4D", "Black", "fgZ456", 45);
        ParkingMeter meter2 = new ParkingMeter(60);
        ParkingTicket ticket2 = officer.issueTicket(car2, meter2);
        System.out.println("Test 2: " + (ticket2 != null ? ticket2.generateTicket() : "Allowed"));

        // Test 3: Car just within the parking time
        ParkedCar car3 = new ParkedCar("Ford", "Fusion", "silver", "GJHF3547", 56);
        ParkingMeter meter3 = new ParkingMeter(60);
        ParkingTicket ticket3 = officer.issueTicket(car3, meter3);
        System.out.println("Test 3: " + (ticket3 != null ? ticket3.generateTicket() : "Allowed"));

        // Test 4: Car just over the parking time
        ParkedCar car4 = new ParkedCar("Toyota", "Mercedes", "White", "DXFFGDX3", 32);
        ParkingMeter meter4 = new ParkingMeter(60);
        ParkingTicket ticket4 = officer.issueTicket(car4, meter4);
        System.out.println("Test 4: " + (ticket4 != null ? ticket4.generateTicket() : "Allowed"));

        // Test 5: Car exactly at the parking time
        ParkedCar car5 = new ParkedCar("BMW", "X5", "blue sky", "DDGGHGE", 25);
        ParkingMeter meter5 = new ParkingMeter(60);
        ParkingTicket ticket5 = officer.issueTicket(car5, meter5);
        System.out.println("Test 5: " + (ticket5 != null ? ticket5.generateTicket() : "Allowed"));

        // Test 6: Car ticketed for less than 1 hour over time
        ParkedCar car6 = new ParkedCar("Hibridy", "Altima", "Gray", "DFGHSA245", 30);
        ParkingMeter meter6 = new ParkingMeter(60);
        ParkingTicket ticket6 = officer.issueTicket(car6, meter6);
        System.out.println("Test 6: " + (ticket6 != null ? ticket6.generateTicket() : "Allowed"));

        // Test 7: Car ticketed for more than 1 hour over time
        ParkedCar car7 = new ParkedCar("Yaris", "XI", "White", "DGGHRYS345", 56);
        ParkingMeter meter7 = new ParkingMeter(60);
        ParkingTicket ticket7 = officer.issueTicket(car7, meter7);
        System.out.println("Test 7: " + (ticket7 != null ? ticket7.generateTicket() : "Allowed"));

        // Test 8: Car ticketed for exactly 1 hour over time
        ParkedCar car8 = new ParkedCar("VOX", "XVC", "Black", "DGSER567", 34);
        ParkingMeter meter8 = new ParkingMeter(60);
        ParkingTicket ticket8 = officer.issueTicket(car8, meter8);
        System.out.println("Test 8: " + (ticket8 != null ? ticket8.generateTicket() : "Allowed"));
    }

    public static void main(String[] args) {
        TestParkingTicket simulator = new TestParkingTicket();
        simulator.runTests();
    }
}