/* Name: MURENGEZI Samuel
 - Reg Number: 20486/2022
 - Class: PizzaTester
 - Description: This is a class which is a simulator that test your ParkingTicket classes.
 - Instance: Display each pizza is displayed after it is created.
 */

import java.util.Scanner;

public class PizzaTester {
    public static void main(String[] args) {
        // Create a default pizza and display it
        Pizza defaultPizza = new Pizza();
        System.out.println("Default pizza: " + defaultPizza);

        // Validate command-line argument
        if (args.length != 1) {
            System.out.println("Usage: java PizzaTester <number_of_pizzas>");
            return;
        }

        int numPizzas;
        try {
            numPizzas = Integer.parseInt(args[0]);
        } catch (NumberFormatException e) {
            System.out.println("Invalid number of pizzas. Please enter an integer.");
            return;
        }

        Scanner scanner = new Scanner(System.in);
        for (int i = 0; i < numPizzas; i++) {
            try {
                System.out.println("order a pizza you want " + (i + 1) + "...");
                System.out.println("Choose a meat option includes:");
                for (Pizza.MeatChoice choice : Pizza.MeatChoice.values()) {
                    System.out.println("- " + choice);
                }
                String meatInput = scanner.nextLine().toUpperCase();
                Pizza.MeatChoice meatChoice;
                try {
                    meatChoice = Pizza.MeatChoice.valueOf(meatInput);
                } catch (IllegalArgumentException e) {
                    throw new InvalidPizzaChoiceException("we don't have a pizza according for what you chosen: " + meatInput);
                }

                System.out.println("we have a different vegetabes choose what you want:");
                for (Pizza.VegChoice choice : Pizza.VegChoice.values()) {
                    System.out.println("- " + choice);
                }
                String vegInput = scanner.nextLine().toUpperCase();
                Pizza.VegChoice vegChoice;
                try {
                    vegChoice = Pizza.VegChoice.valueOf(vegInput);
                } catch (IllegalArgumentException e) {
                    throw new InvalidPizzaChoiceException("we dont have a vegetable according to your choice: " + vegInput);
                }

                Pizza pizza = new Pizza(8, meatChoice, vegChoice);
                System.out.println("Pizza created: " + pizza);

            } catch (InvalidPizzaChoiceException e) {
                System.out.println("Error: " + e.getMessage());
                i--; // Retry current pizza
            }
        }

        scanner.close();
    }
}