/* Name: MURENGEZI Samuel
 - Reg Number: 20486/2022
 - Class: InvalidPizzaChoiceException.
 - Description: custom Exception for invalid data.
 - Instance: Throw and catch when the user responds with an invalid meat or vegetable options.
 */

public class InvalidPizzaChoiceException extends Exception {
    public InvalidPizzaChoiceException(String message) {
        super(message);
}
}