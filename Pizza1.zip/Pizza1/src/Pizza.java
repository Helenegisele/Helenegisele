/* Name: MURENGEZI Samuel
 - Reg Number: 20486/2022
 - Class: Pizza
 - Description: Meat and Vegetables choices.
 - Instance: Manages the display of the randomly generated pizza.
 */

import java.util.Random;

public class Pizza {
    // Enum for meat choices
    public enum MeatChoice {
        PEPPERONI, SAUSAGE, CHICKEN, BACON
    }

    // Enum for vegetable choices
    public enum VegChoice {
        ONION, PEPPERS, MUSHROOMS, OLIVES, SPINACH, TOMATO
    }

    private int numSlices;
    private MeatChoice meatChoice;
    private VegChoice vegChoice;

    // Default constructor
    public Pizza() {
        Random random = new Random();
        this.numSlices = 8; // Default number of slices
        this.meatChoice = MeatChoice.values()[random.nextInt(MeatChoice.values().length)];
        this.vegChoice = VegChoice.values()[random.nextInt(VegChoice.values().length)];
    }

    // Parameterized constructor
    public Pizza(int numSlices, MeatChoice meatChoice, VegChoice vegChoice) {
        this.numSlices = numSlices;
        this.meatChoice = meatChoice;
        this.vegChoice = vegChoice;
    }

    // Getters and setters
    public int getNumSlices() {
        return numSlices;
    }

    public void setNumSlices(int numSlices) {
        if (numSlices <= 0) {
            throw new IllegalArgumentException("Number of slices must be positive.");
        }
        this.numSlices = numSlices;
    }

    public MeatChoice getMeatChoice() {
        return meatChoice;
    }

    public void setMeatChoice(MeatChoice meatChoice) {
        this.meatChoice = meatChoice;
    }

    public VegChoice getVegChoice() {
        return vegChoice;
    }

    public void setVegChoice(VegChoice vegChoice) {
        this.vegChoice = vegChoice;
    }

    // Override toString for display
    @Override
    public String toString() {
        return "Pizza{" +
                "numSlices=" + numSlices +
                ", meatChoice=" + meatChoice +
                ", vegChoice=" + vegChoice +
                '}';
    }
}